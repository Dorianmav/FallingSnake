package snake;

public interface SnakeObserver {
	public void update();
}
